// Import the interfaces
#import "HelloWorldScene.h"
#import "SimpleAudioEngine.h"
#import "GameOverScene.h"
#import "GamePlay.h"

enum  {
	kTagBall, //Player
	kTagEnemy //Asteroids
};

@implementation GamePlay
@synthesize layer = _layer;

- (id)init {
	
    if ((self = [super init])) {
        self.layer = [GamePlayS node];
        [self addChild:_layer];
    }
	
	return self;
}

- (void)dealloc {
    self.layer = nil;
    [super dealloc];
}

@end


// HelloWorld implementation
@implementation GamePlayS

-(void)spriteMoveFinished:(id)sender {
	
	CCSprite *sprite = (CCSprite *)sender;
	[self removeChild:sprite cleanup:YES];
	
	//if (sprite.tag == 1) { // target
	//	[_targets removeObject:sprite];
	
	//GameOverScene * gameOverScene = [GameOverScene node];
	//[gameOverScene.layer.label setString:@""];
	//[[CCDirector sharedDirector] replaceScene:gameOverScene];
	
	// CCSprite * bg = [CCSprite spriteWithFile:@"background3.png"]; //Background of the Game
	// bg.position = ccp(240, 160); //Position
	// [self addChild:bg]; //Add BG

	//} else if (sprite.tag == 2) { // projectile
	//	[_projectiles removeObject:sprite];
	//}
	
}



-(void)addTarget {
	
	CCSprite *target = [CCSprite spriteWithFile:@"asteroid1.png" rect:CGRectMake(0, 0, 60, 60)]; 
	
	// Determine where to spawn the target along the Y axis
	CGSize winSize = [[CCDirector sharedDirector] winSize];
	int minY = target.contentSize.height/2;
	int maxY = winSize.height - target.contentSize.height/2;
	int rangeY = maxY - minY;
	int actualY = (arc4random() % rangeY) + minY;
	
	// Create the target slightly off-screen along the right edge,
	// and along a random position along the Y axis as calculated above
	target.position = ccp(winSize.width + (target.contentSize.width/2), actualY);
	[self addChild:target];
	
	// speed of the target
	int minDuration = 3.5;
	int maxDuration = 4.0;
	int rangeDuration = maxDuration - minDuration;
	int actualDuration = (arc4random() % rangeDuration) + minDuration;
	
	// Create the actions
	id actionMove = [CCMoveTo actionWithDuration:actualDuration position:ccp(-target.contentSize.width/2, actualY)];
	id actionMoveDone = [CCCallFuncN actionWithTarget:self selector:@selector(spriteMoveFinished:)];
	[target runAction:[CCSequence actions:actionMove, actionMoveDone, nil]];
	
	// Add to targets array
	target.tag = 1;
	[_targets addObject:target];
	
}
-(void)addStars {
	
	CCSprite *stars = [CCSprite spriteWithFile:@"star.png" rect:CGRectMake(0, 0, 40, 40)]; //Get Stars and Size of the Stars
	
	// Determine where to spawn the target along the Y axis
	CGSize winSize = [[CCDirector sharedDirector] winSize];
	int minY = stars.contentSize.height/2;
	int maxY = winSize.height - stars.contentSize.height/2;
	int rangeY = maxY - minY;
	int actualY = (arc4random() % rangeY) + minY;
	
	// Create the target slightly off-screen along the right edge,
	// and along a random position along the Y axis as calculated above
	stars.position = ccp(winSize.width + (stars.contentSize.width/2), actualY);
	[self addChild:stars];
	
	// Speed of the Stars
	int minDuration = 1.0;
	int maxDuration = 2.0;
	int rangeDuration = maxDuration - minDuration;
	int actualDuration = (arc4random() % rangeDuration) + minDuration;
	
	// Create the actions
	id actionMove = [CCMoveTo actionWithDuration:actualDuration position:ccp(-stars.contentSize.width/2, actualY)];
	id actionMoveDone = [CCCallFuncN actionWithTarget:self selector:@selector(spriteMoveFinished:)];
	[stars runAction:[CCSequence actions:actionMove, actionMoveDone, nil]];
	
	// Add to Stars array
	stars.tag = 1;
	[_stars addObject:stars];
	
}

//AddAsteriods
-(void)gameLogic:(ccTime)dt {
	
	[self addTarget];
	
} 

//AddStars
-(void)gameLogic1:(ccTime)dt {
	
	[self addStars];
	
} //AddStars

// on "init" you need to initialize your instance
-(id) init
{
	//Super Init
	if( (self=[super init] )) {
		
		// Enable touch events
		self.isTouchEnabled = YES;
		
		//Background
		CCSprite * bg = [CCSprite spriteWithFile:@"background3.png"]; //Background of the Game
		bg.position = ccp(240, 160); //Position
		[self addChild:bg]; //Add BG
		
		// Initialize arrays
		_stars = [[NSMutableArray alloc] init];
		_targets = [[NSMutableArray alloc] init];
		_projectiles = [[NSMutableArray alloc] init];
		
		// Get the dimensions of the window for calculation purposes
		CGSize winSize = [[CCDirector sharedDirector] winSize];
		
		//Main Player
		CCSprite *player = [CCSprite spriteWithFile:@"saucer.png" rect:CGRectMake(0, 0, 100, 65)];
		player.position = ccp(player.contentSize.width/2, winSize.height/2);
		[self addChild:player z:1 tag:kTagBall];
		
		
		
		// Call game logic about every second
		[self schedule:@selector(gameLogic:) interval:1.8];
		[self schedule:@selector(move) interval:.01];
		[self schedule:@selector(gameLogic1:) interval:4.0];
		//[self schedule:@selector(update:)];
		
		// Start up the background music
		[[SimpleAudioEngine sharedEngine] playBackgroundMusic:@"background-music-aac.caf"];
		
		//Collision Detection Variable
		x = 5;
		y = 5;
	}
	return self;
}

//Attack by ASTEROIDS! 
-(void) move{
	CCNode * target = [self getChildByTag:kTagEnemy]; //Get Asteroids
	CCNode * player = [self getChildByTag:kTagBall]; //Get Main Player
	
	if (target.position.x < 480 || target.position.x < 0) {
		x =-x;
	}
	if (target.position.y < 320 || target.position.y < 0) {
		y =-y;
	}
	
	//Collision Detection
	float xDif = target.position.x - player.position.x;
	float yDif = target.position.y - player.position.y;
	float distance = sqrtf(xDif * xDif + yDif * yDif);
	
	//Radius of the Player and Asteroids. PlayerRadius + AsteroidsRadius = Radius
	if(distance < 45) {
		//Once Hit, Stop Spawning Asteroids and Stars.
		[self unschedule:@selector(move)];
		[self unschedule:@selector(gameLogic:)];
		[self unschedule:@selector(gameLogic1:)];
		
		//Show Alert once Hit.
		UIAlertView * alert = [[UIAlertView alloc] initWithTitle:@"SMOKE!" message:@"You got smashed by Asteriod." delegate:self cancelButtonTitle:@"Go to Main Menu" otherButtonTitles:nil];
		[alert show];
		[alert release];
	}
}

-(void) alertView:(UIAlertView *) alert clickButtonAtIndex:(NSUInteger) buttonIndex{
	if(buttonIndex == 0){
		[[CCDirector sharedDirector] replaceScene:[CCTransitionZoomFlipY transitionWithDuration:1 scene:[GameOverScene node]]];
		// Alert Button
		//Tranitions = CCTransitionZoomFlipAngular
	}
}

//To Paused the Game
- (void)pauseGame {
 NSLog(@"Paused!");
 }

//Began to Touch
-(void) ccTouchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
	return;
}
//Move the Player
-(void) ccTouchesMoved:(NSSet *)touches withEvent:(UIEvent *) event{
	UITouch * myTouch = [touches anyObject]; //Able to Touch the Object
	CGPoint point = [myTouch locationInView :[myTouch view]];
	point = [[CCDirector sharedDirector] convertToGL:point];
	
	CCNode * sprite = [self getChildByTag:kTagBall]; //Move
	[sprite setPosition:point]; //Position Set after Moved.
	return;
}

/*- (void)ccTouchesEnded:(NSSet *)touches withEvent:(UIEvent *)event {
 
 // Choose one of the touches to work with
 UITouch *touch = [touches anyObject];
 CGPoint location = [touch locationInView:[touch view]];
 location = [[CCDirector sharedDirector] convertToGL:location];
 
 // Set up initial location of projectile
 CGSize winSize = [[CCDirector sharedDirector] winSize];
 CCSprite *projectile = [CCSprite spriteWithFile:@"Projectile.png" rect:CGRectMake(0, 0, 20, 20)];
 projectile.position = ccp(20, winSize.height/2);
 
 // Determine offset of location to projectile
 int offX = location.x - projectile.position.x;
 int offY = location.y - projectile.position.y;
 
 // Bail out if we are shooting down or backwards
 if (offX <= 0) return;
 
 // Ok to add now - we've double checked position
 [self addChild:projectile];
 
 // Play a sound!
 [[SimpleAudioEngine sharedEngine] playEffect:@"pew-pew-lei.caf"];
 
 // Determine where we wish to shoot the projectile to
 int realX = winSize.width + (projectile.contentSize.width/2);
 float ratio = (float) offY / (float) offX;
 int realY = (realX * ratio) + projectile.position.y;
 CGPoint realDest = ccp(realX, realY);
 
 // Determine the length of how far we're shooting
 int offRealX = realX - projectile.position.x;
 int offRealY = realY - projectile.position.y;
 float length = sqrtf((offRealX*offRealX)+(offRealY*offRealY));
 float velocity = 480/1; // 480pixels/1sec
 float realMoveDuration = length/velocity;
 
 // Move projectile to actual endpoint
 [projectile runAction:[CCSequence actions:
 [CCMoveTo actionWithDuration:realMoveDuration position:realDest],
 [CCCallFuncN actionWithTarget:self selector:@selector(spriteMoveFinished:)],
 nil]];
 
 // Add to projectiles array
 projectile.tag = 2;
 [_projectiles addObject:projectile];
 
 }*/

// on "dealloc" you need to release all your retained objects
- (void) dealloc
{
	//Release the Targets and the Stars
	[_targets release];
	_targets = nil;
	[_stars release];
	_stars = nil;
	//[_projectiles release];
	//_projectiles = nil;
	
	// don't forget to call "super dealloc"
	[super dealloc];
}
@end
