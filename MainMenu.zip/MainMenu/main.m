//
//  main.m
//  MainMenu
//
//  Created by DUCA on 7/17/12.
//  Copyright __MyCompanyName__ 2012. All rights reserved.
//

#import <UIKit/UIKit.h>

int main(int argc, char *argv[]) {
	NSAutoreleasePool *pool = [NSAutoreleasePool new];
	int retVal = UIApplicationMain(argc, argv, nil, @"MainMenuAppDelegate");
	[pool release];
	return retVal;
}
