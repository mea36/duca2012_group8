//
//  GamePlay.h
//  Ball Dodge
//
//  Created by DUCA on 7/18/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import "cocos2d.h"


@interface GamePlay : CCLayer { //Change to CCLayer
	int x, y;
}
/*+(id)scene{
}*/
@end
