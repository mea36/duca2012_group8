//
//  GamePlay.m
//  Ball Dodge
//
//  Created by DUCA on 7/18/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import "GamePlay.h"
#import "HelloWorldLayer.h"

//#import "Hello
enum {
	kTagBall,
	kTagEnemy,
	kTagStars
};

@implementation GamePlay
+(id) scene{ //Copy the Scene from HelloWorldLayer
	// 'scene' is an autorelease object.
	CCScene *scene = [CCScene node];
	
	// 'layer' is an autorelease object.
	GamePlay *layer = [GamePlay node]; //This Different.
	// Change World to this class Name GamePlay samething with the second part.
	
	// add layer as a child to scene
	[scene addChild: layer];
	
	// return the scene
	return scene;
}
-(id) init{
	if( (self = [super init])){
		self.isTouchEnabled = YES; //Enabled the Touch 
		CCSprite * bg = [CCSprite spriteWithFile:@"background3.png"]; //Background of the Game
		bg.position = ccp(240, 160); //Position
		[self addChild:bg]; //Add BG
		
		// All the Gameplay goes here!
		CCSprite * stars = [CCSprite spriteWithFile:@"star.png"];
		stars.position = ccp(200, 40);
		[self addChild:stars z:1 tag:kTagStars];
		CCSprite * ball = [CCSprite spriteWithFile:@"saucer1.png"]; //Sprite of the Game
		ball.position = ccp(240, 40);//Position of the Game
		[self addChild:ball z:2 tag:kTagBall]; //Add the Sprite in the Game
		CCSprite * enemy = [CCSprite spriteWithFile:@"asteroid1.png"];//Sprite of the Game
		enemy.position = ccp(240, 280);//Position of the Game
		[self addChild:enemy z:3 tag:kTagEnemy];//Add the Sprite in the Game
		[self schedule:@selector(move) interval:.01]; //When to Start
		/*[self schedule:@selector(check) interval:.01];*/
		x=5;
		y=5;
	}
	return self;
}
-(void) move{ //Move the Player
	CCNode * enemy = [self getChildByTag:kTagEnemy];
	CCNode * ball = [self getChildByTag:kTagBall];
	CCNode * stars = [self getChildByTag:kTagStars];
	if(enemy.position.x > 480 || enemy.position.x < 0){
		x =- x;
	}
	if(enemy.position.y > 320 || enemy.position.y < 0){
		y =- y;
	}
	
	enemy.position = ccp(enemy.position.x + x, enemy.position.y + y);
	
	//collision detection
	float xDif = enemy.position.x - ball.position.x;
	float yDif = enemy.position.y - ball.position.y;
	float distance = sqrt(xDif * xDif + yDif * yDif);
	
	// Radius of the Image (Player/Enemy
	if(distance < 50 ) { 
		[self unschedule:@selector(move)];
		UIAlertView * alert = [[UIAlertView alloc] initWithTitle:@"SMOKE!" message:@"You got smashed by Asteriod." delegate:self cancelButtonTitle:@"Go to Main Menu" otherButtonTitles:nil];
		[alert show];
		[alert release];
	}
}
-(void) alertView:(UIAlertView *) alert clickButtonAtIndex:(NSUInteger) buttonIndex{
	if(buttonIndex == 0){
		[[CCDirector sharedDirector] replaceScene:[CCTransitionZoomFlipAngular transitionWithDuration:1 scene:[HelloWorldLayer node]]];
		// Alert Button
	}
}
-(BOOL) ccTouchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
	
	return YES;
}
-(BOOL) ccTouchesMoved:(NSSet *)touches withEvent:(UIEvent *) event{
	UITouch * myTouch = [touches anyObject];
	CGPoint point = [myTouch locationInView :[myTouch view]];
	point = [[CCDirector sharedDirector] convertToGL:point];
	
	CCNode * sprite = [self getChildByTag:kTagBall];
	[sprite setPosition:point];
	return YES;
}
@end
